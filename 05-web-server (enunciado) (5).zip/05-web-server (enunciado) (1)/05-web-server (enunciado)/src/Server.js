function createServer() {
  throw new Error('implementar!')
}

export { createServer }