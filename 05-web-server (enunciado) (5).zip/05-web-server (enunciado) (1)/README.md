


     DOCUMENTACION;


Esta es una api simple y ajustada 100% centrada en un programa dedicado al registro de alumnos en una escuela en la que podran registrar,eliminar , modificar y buscar alumnos, en este programa no  cuenta con funciones solo para buscar alumnos sino que esta con busqueda personalisada (por edad) o busquedas mas precisas de un solo alumno (con dni),
el programa funciona en 3 etapas la primera la de los datos en este caso de alumnos ,la segunda la de las funciones utilisada como las anteriormente nombrada y la ultima la de la conexion con el usuario del programa atraves de peticiones 
por las rutas en este caso put(para modificar ),post(agregar alumno),delete(eliminar alumno), y los get (que muestran ya sea un alumno o todos incluso en orden de edad),en la que mediante verificaciones hechas en estas puede validarse si esta mostrarn/accionaran lo solicitado o mostraran errores en caso de que alguna condicion definida para que este optimo no se cumpla en este caso mostrara un mensaje de error que puede estar personalisado para el usuario.
La manera en la que funciona esto mediante las estas tres etapas es la siguiente los datos hechos en la primer parte interactuan con las funciones de la segunda los cuales se encargan de modificarlo al agragar eliminar y cambiar datos, luego estas funciones son dirigidas por las peticiones de la tercera etapa hechas por el usuario que mediante las rutas que soliciten pueden llamar a estos metodos.



                                           Ejemplo de una peticion:

app.get('/:id', async (req, res) => {
	const alumno = await buscarporid(req.params.id);
	if (alumno) {
		res.json(alumno);
	} else {
		res.status(404).send('Alumno no encontrado');
	}
});

en esta peticion de tipo get muestra  a un alumno especificado por el usuario por dni o un mensaje de error personalisado 
'Alumno no encontrado' en caso de que no cumpla con algun requisito solicitado en este caso que el alumno no exista en el registro de alumnos para saber eso se hace un await para esperar que se guarde la busqueda del alumno por una funcion creada en la etapa anterior que se encarcarga de recorer todo los alumno guardados de la primer etapa y a cada uno se lo iguala con su dni con el que es pasado por parametro que  a la vez es recibido por parte del usuario para esta petcion
que en caso que exista le devolvera el alumno con el dni solicitado.

             las peticiones  son:



get('/',  async function (req, res, next)
encargado de traer todo los alumno o dar un mendsaje de error

get('/:edad',  async function (req, res, next)
encargado de traer todo los alumno ordenados en un rango de edad o dar un mendsaje de error

get('/:id', async (req, res)
encargado de traer al alumno con el dni especificado por el usuario o dar un mendsaje de error

post('/', async (req, res)
encargado de agregar al registro un nuevo alumno o dar un mendsaje de error

put('/:id', async (req, res)
encargado de modificar un alumno especificado con un id dado por el usuario  o dar un mendsaje de error

delete('/:id',  async (req, res)
encargado de eliminar un alumno especificado con un id dado por el usuario  o dar un mendsaje de error