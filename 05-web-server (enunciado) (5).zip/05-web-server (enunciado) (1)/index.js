//const express =require('express');
//const http =require('http');
//const app=express();
//const port=2198;
//const routes =require('./routes/server.test');
//app.use('/escuela',routes());
//app.use('/',routes().get);
//app.listen(2198);
//var server = http.createServer(Request);
//function crearServidor(port) {
//    const promesaDeServidorConectado = new Promise((resolve, reject) => {
//    const server = app.listen(port)
//    server.on('listening', () => { resolve(server) })
//    server.on('error', error => { reject(error) })
 //   })
//    return promesaDeServidorConectado
//    }
//    crearServidor(port)
    