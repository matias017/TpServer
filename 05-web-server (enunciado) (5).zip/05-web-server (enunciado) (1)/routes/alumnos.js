var URLactual = window.location;
alert(URLactual);