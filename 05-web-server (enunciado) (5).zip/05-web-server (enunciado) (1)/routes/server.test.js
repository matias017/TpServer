const express =require('express');
const app=express();
let router = express.Router();
app.listen(2198);

const joi = require('joi');

//primero configurarlo y despues exportarlo



const estuValido = {
    nombre: 'mariano',
    apellido: 'aquino',
    edad: 34,
    dni: '123'
}

const estuValido2 = {
    nombre: 'juana',
    apellido: 'perez',
    edad: 35,
    dni: '456'
}
let estudiantes =[estuValido,
    estuValido2];

  //  app.get('/', function (req, res, next) {
  //      res.send('estudiantes')
  //    })

app.get('/',  async function (req, res, next) {
	const alumnos = await mostrarAlumnos();
	res.send(alumnos);
});

app.get('/edad',  async function (req, res, next) {
	const alumnos = await buscarporedad();
	res.send(alumnos);
});

app.get('/:dni', async (req, res) => {
	const alumno = await buscarpordni(req.params.dni);
	if (alumno!==null) {
        console.lod("pasa algo raro");
		res.send(alumno);
	} else {
		res.status(404).send('Alumno no encontrado');
	}
});

app.post('/', async (req, res) => {
	const schema = joi.object({
        npmbre: joi.string().alphanum().min(3).required(),
        apellido: joi.string().alphanum().min(3).required(),
        edad: joi.number().required(),
        dni: joi.string().alphanum().min(3).max(7).required(),
	});
	const body = req.body;

	const result = schema.validate(body);

	if (result.error) {
		res.status(400).send(result.error.details[0].message);
	} else {
		let alumno = body;
		await cargarAlumno(alumno);
		res.status(200).json(alumno);
	}
});

app.put('/:id', async (req, res) => {
    const schema = joi.object({
        nombre: joi.string().alphanum().min(3).required(),
        apellido: joi.string().alphanum().min(3).required(),
        edad: joi.number().required(),
        dni: joi.string().alphanum().min(3).max(7).required(),
    });
    const body = req.body;
    const result = schema.validate(body);

    if (result.error) {
        res.status(400).send(result.error.details[0].message);
    } else {
        let alumno = body;
        await cambiarAlumno(req.params.id);
        res.status(200).json(alumno);
    }
});

app.delete('/:id',  async (req, res) => {
	const alumno = await eliminarAlumno(req.params.id);

	if (!alumno) {
		res.status(400).send(error.message);
	} else {
		res.json(alumno);
	}
});

module.exports=function(){
    router.get('/escuela');
    return router;

}


function mostrarAlumnos(){
    return estudiantes;
}
function buscarpordni( dni){
    let i=0;
    let result;
    while( i<estudiantes.lenght&&result==null){
      let e =estudiantes[i];
      if(e.dni==dni){
          result=e;
      }
     
    }
    return result;
}

function buscarporid( id){
    let i=0;
    let result;
    while( i<estudiantes.lenght&&result==null){
      let e =estudiantes[i];
      if(i==id){
          result=e;
      }
     
    }
    return result;
}

function buscarporedad( ){
return  estudiantes.sort(function (a, b) {
        var x = a.edad,
        y = b.edad;
            retrun ((x < y) ? -1 : ((x > y) ? 1 : 0));

        });
    }

function cargarAlumno(alumnoNuevo){
    let existe=buscarpordni(alumnoNuevo.dni);
    if(existe==null){
        estudiantes.push(alumnoNuevo)
    }
    
}

function eliminarAlumno(id){
    let existe=buscarporid(id);
    if(estudiantes[i]!==null){
 //       let pos=0;
 //       for(var i=0;i<estudiantes.lenght;i++){
 //           var e =estudiantes[i];
 //           result=null;
 //           if(e!==alumno){
 //               pos++;
 //           }
           
//          }
        estudiantes.splice(i,1)
    }
    return estudiantes[i]
}

function cambiarAlumno(id){
    let existe=buscarporid(id);
    if(existe!==null){
        let pos=0;
        for(var i=0;i<estudiantes.lenght;i++){
            var e =estudiantes[i];
            result=null;
            if(e!==alumno){
                pos++;
            }
           
          }
        estudiantes.splice(pos,1,alumno)
    }
    
}


//describe('...', () => {
 //   it('...', () => {

 //   })
//})
